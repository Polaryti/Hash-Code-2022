o_file = 'data/output/a_an_example.out.txt'

def output_process(solution):

    with open(o_file, 'w') as f:
        f.write(str(len(solution)) + '\n')
        for project, people in solution.items():
            f.write(project + '\n')
            for person in list(people):
                f.write(person + " ")
            f.write('\n')