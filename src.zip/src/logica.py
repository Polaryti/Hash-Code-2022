from input import input_process
from output import output_process



def skill_possible(project_skills, pearson_skills):
    for project_skill, skill_score in project_skills.items():
        for pearson_skill_, score in pearson_skills.items():
            if project_skill == pearson_skill_ and skill_score <= score:
                return project_skill
    return False

def is_possible(project, people, schedule, day, duration):
    workers = []
    for p, skills in people.items():
        if schedule[p][day] == 0:
            sk = skill_possible(project['roles'], skills[0])
            if not sk:
                pass
            else:
                workers.append(p)
                del project['roles'][sk]
                for i in range(duration):
                    schedule[p][day + i] = 1
        if project['roles'] == {}:
            return workers
    return False              

if __name__ == "__main__":
    schedule = {}
    solution = {}
    file = 'data/a_an_example.in.txt'

    people, projects = input_process(file)
    for p in list(people.keys()):
        schedule[p] = [0] * 10000
    
    day = 0
    for _, pro in projects.items():
        duration = int(pro['days'])
        res = is_possible(pro, people, schedule, day, duration)

        if res is not False:
            solution[pro['name']] = res

        day += duration

        
    output_process(solution)

